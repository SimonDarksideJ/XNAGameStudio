Unit Converter Starter Kit 
 
This Windows Phone 7 Starter Kit is a complete Unit Converter application written in C#. 
The program provides the user with the ability to convert values from one unit of measure to another.

To view the documentation that accompanies this starter kit, open the UnitConverter.sln solution file in Visual Studio. 
Then right click on Unit Converter Starter Kit.htm in the Solution Explorer and click �View in Browser�. 
You can also view the documentation online at http://go.microsoft.com/fwlink/?LinkID=206276. 

Important:  
You must install Windows Phone Developer Tools to run this sample. 
To get started, go to the App Hub at http://go.microsoft.com/fwlink/?LinkID=185192. 
