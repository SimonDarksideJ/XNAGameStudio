﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Avatar Animation Blending")]
[assembly: AssemblyProduct("AvatarAnimationBlendingSample")]
[assembly: AssemblyDescription("This sample demonstrates how to blend animations for playback on an avatar.")]
[assembly: AssemblyCompany("Microsoft")]
[assembly: AssemblyCopyright("Copyright © Microsoft 2009")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible
// to COM components. Xbox 360 assemblies do not support COM.
[assembly: ComVisible(false)]

// If this assembly is the startup assembly, the following Guid is used to
// uniquely identify the title storage container when deploying this assembly
// to the Xbox 360 console.
[assembly: Guid("54b9c9c8-2dde-4013-88cb-d2e9ff6b36ee")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
[assembly: AssemblyVersion("1.0.0.0")]