Level Starter Kit 
 
This Windows Phone 7 Starter Kit is a complete Level application written in C#. 
The program provides the user with the ability to use their phone as a level.

To view the documentation that accompanies this starter kit, open the Level.sln solution file in Visual Studio. 
Then right click on Level Starter Kit.htm in the Solution Explorer and click �View in Browser�. 
You can also view the documentation online at http://go.microsoft.com/fwlink/?LinkID=204960. 

Important:  
You must install Windows Phone Developer Tools to run this sample. 
To get started, go to the App Hub at http://go.microsoft.com/fwlink/?LinkID=185192. 
