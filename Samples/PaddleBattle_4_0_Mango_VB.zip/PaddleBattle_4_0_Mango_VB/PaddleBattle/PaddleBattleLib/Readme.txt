﻿The PaddleBattleLib is used as a bridge between the PaddleBattleContent project and the
PaddleBattle project. Because Silverlight is not able to build content projects, this 
XNA Game Studio Library project is referenced by the Silverlight application and builds 
the content for the game.

You can place code inside the library if you want, but you don't have to use it other than
as the bridge between the Silverlight application and the content project.