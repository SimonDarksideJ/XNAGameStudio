#region File Description
//-----------------------------------------------------------------------------
// GameResult.cs
//
// XNA Community Game Platform
// Copyright (C) Microsoft Corporation. All rights reserved.
//-----------------------------------------------------------------------------
#endregion

#region Using Statements
using System;
#endregion

namespace Minjie
{
    enum GameResult
    {
        Player1Won,
        Player2Won,
        Tied,
    }
}
