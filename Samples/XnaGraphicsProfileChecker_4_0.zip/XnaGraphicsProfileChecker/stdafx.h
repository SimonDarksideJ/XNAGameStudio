//-----------------------------------------------------------------------------
// stdafx.h
//
// Microsoft XNA Community Game Platform
// Copyright (C) Microsoft Corporation. All rights reserved.
//-----------------------------------------------------------------------------

#pragma once

#include <d3d9.h>
