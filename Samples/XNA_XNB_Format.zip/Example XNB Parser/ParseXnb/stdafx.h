#pragma once

#include <stdint.h>
#include <stdio.h>
#include <stdarg.h>
#include <assert.h>

#include <algorithm>
#include <exception>
#include <type_traits>
#include <string>
#include <vector>

using namespace std;
