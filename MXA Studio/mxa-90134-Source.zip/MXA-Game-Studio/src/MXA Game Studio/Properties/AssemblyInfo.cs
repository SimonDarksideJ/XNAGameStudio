﻿using System;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("MXA Game Studio")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Insma Software")]
[assembly: AssemblyProduct("MXA Game Studio")]
[assembly: AssemblyCopyright("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]   
[assembly: ComVisible(false)]     
[assembly: CLSCompliant(false)]
[assembly: NeutralResourcesLanguage("en-US")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Revision and Build Numbers 
// by using the '*' as shown below:

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]

[assembly: InternalsVisibleTo("MXA Game Studio_IntegrationTests, PublicKey=00240000048000009400000006020000002400005253413100040000010001000be9ff9fc0f73bf92491567c0a94fe8d1e3a58cc807600e25fd8e7b7878cdfd60f47ddd6ea682613269843d9782ac8b806c42e32798e19951f8352e197be03c999ec99e92f0e5e3012185eb938f7444d560fad1e66ac30c6befd0188244664fc1676ba9b1053040b23f2e0c4204c74c368e6cc8f3e70f68ff25f1ec4541733bf")]
[assembly: InternalsVisibleTo("MXA Game Studio_UnitTests, PublicKey=00240000048000009400000006020000002400005253413100040000010001000be9ff9fc0f73bf92491567c0a94fe8d1e3a58cc807600e25fd8e7b7878cdfd60f47ddd6ea682613269843d9782ac8b806c42e32798e19951f8352e197be03c999ec99e92f0e5e3012185eb938f7444d560fad1e66ac30c6befd0188244664fc1676ba9b1053040b23f2e0c4204c74c368e6cc8f3e70f68ff25f1ec4541733bf")]
