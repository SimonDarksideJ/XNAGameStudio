# MXA Game Studio

Visual Studio extension allows to use MXA Framework.

## Licensing
 
MIT

## Resources

* [Downloads](https://github.com/insma/MXA-Game-Studio/releases)
* [Documentation](https://github.com/insma/MXA-Game-Studio/wiki)

## Related projects

* [MXA Framework](https://github.com/insma/MXA-Framework)
* [SharpDX](https://github.com/sharpdx/SharpDX)
* [ShaprDX Toolkit](https://github.com/sharpdx/Toolkit)
