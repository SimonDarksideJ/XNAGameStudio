﻿using System;

namespace Insma.Mxa.Framework.Graphics {
	public enum PrimitiveType {
		TriangleList = 0,
		TriangleStrip = 1,
		LineList = 2,
		LineStrip = 3,
	}
}
