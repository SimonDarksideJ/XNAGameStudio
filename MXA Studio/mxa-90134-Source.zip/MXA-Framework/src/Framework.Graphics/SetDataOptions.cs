﻿using System;

namespace Insma.Mxa.Framework.Graphics {
	public enum SetDataOptions {
		None = 0,
		Discard = 1,
		NoOverwrite = 2,
	}
}
