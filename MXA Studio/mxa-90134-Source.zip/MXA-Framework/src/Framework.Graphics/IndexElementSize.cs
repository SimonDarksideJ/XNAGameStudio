﻿using System;

namespace Insma.Mxa.Framework.Graphics {
	public enum IndexElementSize {
		SixteenBits = 0,
		ThirtyTwoBits = 1,
	}
}
