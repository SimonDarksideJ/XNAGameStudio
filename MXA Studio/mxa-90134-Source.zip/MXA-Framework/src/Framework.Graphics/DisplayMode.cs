﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Insma.Mxa.Framework.Graphics {
	public class DisplayMode {
		public override string ToString( ) { throw new NotImplementedException( ); }

		public float AspectRatio { get { throw new NotImplementedException( ); } }
		public SurfaceFormat Format { get { throw new NotImplementedException( ); } }
		public int Height { get { throw new NotImplementedException( ); } }
		public Rectangle TitleSafeArea { get { throw new NotImplementedException( ); } }
		public int Width { get { throw new NotImplementedException( ); } }
	}
}
