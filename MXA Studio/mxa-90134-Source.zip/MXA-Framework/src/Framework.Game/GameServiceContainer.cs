﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Insma.Mxa.Framework {
	public class GameServiceContainer : IServiceProvider {
		public GameServiceContainer( ) { throw new NotImplementedException( ); }

		public void AddService(Type type, object provider) { throw new NotImplementedException( ); }
		public object GetService(Type type) { throw new NotImplementedException( ); }
		public void RemoveService(Type type) { throw new NotImplementedException( ); }
	}
}
