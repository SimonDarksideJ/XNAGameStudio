﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Insma.Mxa.Framework.GamerServices {
	public class GamerServicesComponent : GameComponent {
		public GamerServicesComponent(Game game) : base(game) { throw new NotImplementedException( ); }

		public override void Initialize( ) { throw new NotImplementedException( ); }
		public override void Update(GameTime gameTime) { throw new NotImplementedException( ); }
	}
}
