﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Insma.Mxa.Framework.Graphics;

namespace Insma.Mxa.Framework {
	public class GraphicsDeviceInformation {
		public GraphicsDeviceInformation( ) { throw new NotImplementedException( ); }

		public GraphicsDeviceInformation Clone( ) { throw new NotImplementedException( ); }
		public override bool Equals(object obj) { throw new NotImplementedException( ); }
		public override int GetHashCode( ) { throw new NotImplementedException( ); }

		public GraphicsAdapter Adapter { get { throw new NotImplementedException( ); } set { throw new NotImplementedException( ); } }
		public GraphicsProfile GraphicsProfile { get { throw new NotImplementedException( ); } set { throw new NotImplementedException( ); } }
		public PresentationParameters PresentationParameters { get { throw new NotImplementedException( ); } set { throw new NotImplementedException( ); } }
	}
}
