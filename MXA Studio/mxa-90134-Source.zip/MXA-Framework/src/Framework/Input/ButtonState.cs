﻿using System;

namespace Insma.Mxa.Framework.Input {
	public enum ButtonState {
		Released = 0,
		Pressed = 1,
	}
}
