﻿using System;

namespace Insma.Mxa.Framework.Input {
	public enum KeyState {
		Up = 0,
		Down = 1,
	}
}
