﻿using System;

namespace Insma.Mxa.Framework.Input {
	public enum GamePadDeadZone {
		None = 0,
		IndependentAxes = 1,
		Circular = 2,
	}
}
