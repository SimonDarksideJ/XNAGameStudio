﻿
namespace Insma.Mxa.Framework.Graphics.PackedVector {
	public interface IPackedVector<TPacked> : IPackedVector {
		TPacked PackedValue { get; set; }
	}
}
