﻿using System;

namespace Insma.Mxa.Framework {
	public enum CurveTangent {
		Flat = 0,
		Linear = 1,
		Smooth = 2,
	}
}
