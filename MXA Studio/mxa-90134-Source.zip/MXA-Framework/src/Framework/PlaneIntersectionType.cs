﻿using System;

namespace Insma.Mxa.Framework {
	public enum PlaneIntersectionType {
		Front = 0,
		Back = 1,
		Intersecting = 2,
	}
}
