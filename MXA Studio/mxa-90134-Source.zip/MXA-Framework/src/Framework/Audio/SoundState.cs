﻿using System;

namespace Insma.Mxa.Framework.Audio {
	public enum SoundState {
		Playing = 0,
		Paused = 1,
		Stopped = 2,
	}
}
