﻿using System;

namespace Insma.Mxa.Framework.Audio {
	public enum MicrophoneState {
		Started = 0,
		Stopped = 1,
	}
}
