﻿using System;

namespace Insma.Mxa.Framework.Audio {
	public enum AudioChannels {
		Mono = 1,
		Stereo = 2,
	}
}
