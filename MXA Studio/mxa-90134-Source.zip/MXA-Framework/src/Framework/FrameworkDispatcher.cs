﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Insma.Mxa.Framework {
	public static class FrameworkDispatcher {
		public static void Update( ) { throw new NotImplementedException( ); }
	}
}
