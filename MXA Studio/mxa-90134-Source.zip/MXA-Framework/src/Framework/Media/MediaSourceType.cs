﻿using System;

namespace Insma.Mxa.Framework.Media {
	public enum MediaSourceType {
		LocalDevice = 0,
		WindowsMediaConnect = 4,
	}
}
