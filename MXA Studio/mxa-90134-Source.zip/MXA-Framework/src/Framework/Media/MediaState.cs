﻿using System;

namespace Insma.Mxa.Framework.Media {
	public enum MediaState {
		Stopped = 0,
		Playing = 1,
		Paused = 2,
	}
}
