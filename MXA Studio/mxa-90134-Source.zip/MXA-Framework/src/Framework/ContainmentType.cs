﻿using System;

namespace Insma.Mxa.Framework {
	public enum ContainmentType {
		Disjoint = 0,
		Contains = 1,
		Intersects = 2,
	}
}
