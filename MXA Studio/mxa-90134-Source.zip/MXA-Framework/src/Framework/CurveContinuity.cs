﻿using System;

namespace Insma.Mxa.Framework {
	public enum CurveContinuity {
		Smooth = 0,
		Step = 1,
	}
}
