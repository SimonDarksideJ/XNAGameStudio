﻿using System;

namespace Insma.Mxa.Framework {
	public enum DisplayOrientation {
		Default = 0,
		LandscapeLeft = 1,
		LandscapeRight = 2,
		Portrait = 4,
	}
}
