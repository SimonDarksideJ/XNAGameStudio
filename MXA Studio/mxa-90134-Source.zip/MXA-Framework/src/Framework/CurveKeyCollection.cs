﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Insma.Mxa.Framework {
	public class CurveKeyCollection : ICollection<CurveKey>, IEnumerable<CurveKey>, IEnumerable {
		public CurveKeyCollection( ) { throw new NotImplementedException( ); }
		public void Add(CurveKey item) { throw new NotImplementedException( ); }
		public void Clear( ) { throw new NotImplementedException( ); }
		public CurveKeyCollection Clone( ) { throw new NotImplementedException( ); }
		public bool Contains(CurveKey item) { throw new NotImplementedException( ); }
		public void CopyTo(CurveKey[] array, int arrayIndex) { throw new NotImplementedException( ); }
		public IEnumerator<CurveKey> GetEnumerator( ) { throw new NotImplementedException( ); }
		IEnumerator IEnumerable.GetEnumerator( ) { throw new NotImplementedException( ); }
		public int IndexOf(CurveKey item) { throw new NotImplementedException( ); }
		public bool Remove(CurveKey item) { throw new NotImplementedException( ); }
		public void RemoveAt(int index) { throw new NotImplementedException( ); }
		public int Count { get { throw new NotImplementedException( ); } }
		public bool IsReadOnly { get { throw new NotImplementedException( ); } }
		public CurveKey this[int index] { get { throw new NotImplementedException( ); } set { throw new NotImplementedException( ); } }
	}
}
