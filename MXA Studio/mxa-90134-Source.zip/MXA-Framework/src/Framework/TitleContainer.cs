﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Insma.Mxa.Framework {
	public static class TitleContainer {
		public static Stream OpenStream(string name) { throw new NotImplementedException( ); }
	}
}
